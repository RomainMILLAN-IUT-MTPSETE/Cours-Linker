package fr.skytor.studio.manager;

import java.util.ArrayList;

public class configurator {

    public static boolean QuickVoice = true;


    //QuickVoice
    public static String idChannelPublicRoomCreator = "903929707223978065";
    public static String idParentPublicRoomCreator = "884762060414668812";
    public static ArrayList<String> idDoNotDeleteChannel = new ArrayList<>();

}
