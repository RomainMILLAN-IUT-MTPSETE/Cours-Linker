
const Position = (x, y) => ({ name:'Position', x , y });

export {Position}