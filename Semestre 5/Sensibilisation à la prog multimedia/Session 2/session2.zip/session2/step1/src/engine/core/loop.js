"use strict"



// fonction start scene
function start(scene) 
{
//TODO
}

//arret de la boucle de jeu

function stop() {
//TODO

}

export {start, stop}