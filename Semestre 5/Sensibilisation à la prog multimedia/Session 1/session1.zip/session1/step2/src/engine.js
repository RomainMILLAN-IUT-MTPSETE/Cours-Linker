
"use strict"; 




window.onload = function() {
    //TODO

}