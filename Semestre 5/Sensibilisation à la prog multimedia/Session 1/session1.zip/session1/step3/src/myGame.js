import * as engine from "./engine.js";

//Code exemple pour creer un point (x,y)
//a ne pas modifier
function createPoint(x,y)
{
    const gameObj1 = engine.ecs.createEntity();
    engine.ecs.addComponent(gameObj1,engine.components.Position(x,y));
}



// fonction pour dessiner la scene
function sceneSetup()
{
    //TODO
    //exemple:
    createPoint(-0.5,+0.5);
}


//fonction qui initialise l'environnement graphique
//a ne pas modifier
window.onload = function() {
    engine.init("GLCanvas");
    sceneSetup();
    engine.update(); 
}
