# Romain MILLAN IUT MTP/SETE - Casse Brique

Projet étudiant lors du cour de sensibilisation à la programation multimédia au cour du Semestre 5 du BUT Informatique à l'IUT de Montpellier/Sète.
<br/>
Une version jouable en ligne est disponible sur http://casse-brique.romainmillan.fr/.
Le github est disponible sur le lien suivant https://github.com/RomainMILLAN-IUT-MTPSETE/Casse-Brique.

### Technologies

- HTML
- CSS
- JavaScript
- WebGL

<br/>
<br/>
<br/>

![Fait par Romain MILLAN](https://github.com/RomainMILLAN-IUT-MTPSETE/Casse-Brique/assets/42139000/d4f0e220-b3ee-418b-9dd9-6b3c7fee362c)
